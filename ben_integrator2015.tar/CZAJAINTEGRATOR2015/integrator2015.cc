#include "vec3d.h"
#include <iostream>
#include <algorithm>
#include <math.h>
#include <stdio.h>
#include <fstream>
#include <iomanip>
#include <string.h>

using namespace std;
const double PI = acos(-1.0);
double arcsec_to_radian(double arcsec);
double radian_to_arcsec(double radian);
void convertfly(double &X,double &Y,double &Z,double &U,double &Uer,double &V,double &Ver,double &W,double &Wer,double &Rapo,double &Rapoplus,double &Rapominus,double &Rperi,double &Rperiplus,double &Rperiminus,double &zheight,double &zheightplus,double &zheightminus,double &LX,double &LXplus,double &LXminus,double &LY,double &LYplus,double &LYminus,double &LZ,double &sigLZ,double &Lperp,double &sigLperp,double &ecc,double &eccplus,double &eccminus,double &Energy,double &Energyplus,double &Energyminus,double &period,double &periodplus,double &periodminus,double alpha,double delta,double pi,double pi_error,double ro,double ro_error,double mualpha,double mualpha_error,double mudelta,double mudelta_error,int choice,double run,const int N);

//Start of the MAIN==================================
int main(int argc,char *argv[]){

  if(argc < 7){
    cerr<<" You need 6 Arguments....... 'inputfile.dat' 'outputfile.dat' 'potential#' 'length of integration in gigayears' 'distancetype 0 for arcsec, 1 for parsec' '0 for no errors or 1 for errors'\n";
    exit(0);
  }

  //Making sure user input proper errors choice (1 for yes, 0 for no)
  int errorchoice = atoi(string(argv[6]).c_str());
  if(errorchoice > 1 || errorchoice < 0){
    cerr<<"Improper argument given for errors... Must input 0 for no, 1 for yes "<<endl;
    exit(0); 
  }
  int N;
  if(errorchoice ==0){N = 1;}else {N = 64;}

//Making sure that the proper choice was given for distance type (arcsec or parsec)
  int distancechoice = atoi(string(argv[5]).c_str());
  if(distancechoice > 1 || distancechoice < 0){
    cerr<<"Improper argument given for disance choice... Must input 0 for arcsec, 1 for parsec"<<endl;
    exit(0); 
  }

  //converting the string to a double for runtime in GIGA years
  double run = atof(string(argv[4]).c_str());

  //Determining the choice of Milky Way Potenial
  int choice = atoi(string(argv[3]).c_str());
  if(choice !=1 && choice !=2 && choice !=3 && choice !=4 && choice !=5){
    cerr<<"You did not enter 1, 2, 3, 4,or 5 Try again\n";
    exit(0);
  }
  /*
    Choice (1)..................Kenyon et al. 2008
    Choice (2)..................Paczynski B. 1990
    Choice (3)..................Jonhston K. V., Spergel D. N., Hernquist 1995
    Choice (4)..................Dauphole B., Colin J. 1995
    Choice (5)..................Allen C., Santillan A. 1991
  */

  FILE * tmp;
  //Reading in input and output file names and location
  string inputfile = string(argv[1]),outputfile = string(argv[2]);
  char inputfilec[255],outputfilec[255];
  strcpy(inputfilec,inputfile.c_str());  strcpy(outputfilec,outputfile.c_str());  
  tmp = fopen(inputfilec,"r");  
  ofstream outfile;
  outfile.open(outputfilec);

  char starname[255];
  double X=0,Y=0,Z=0,U=0,Uer=0,V=0,Ver=0,W=0,Wer=0,Rapo=0,Rapoplus=0,Rapominus=0,Rperi=0,Rperiplus=0,Rperiminus=0,zheight=0,zheightplus=0,zheightminus=0,LX=0,LXplus=0,LXminus=0,LY=0,LYplus=0,LYminus=0,LZ=0,sigLZ=0,Lperp=0,sigLperp=0,ecc=0,eccplus=0,eccminus=0,Energy=0,Energyplus=0,Energyminus=0,period=0,periodplus=0,periodminus=0;
  double epoch=0,RA=0,DEC=0;
  double alpha=0; //RA
  double delta=0; //DEC
  double pi = 0;  //paralax in arcsecs
  double ro = 0; // radial velocity in km/s
  double mualpha =0; //proper motion in RA
  double mudelta =0; //proper motion in DEC
  double ro_err=0,pi_err=0,mualpha_err=0,mudelta_err=0;
  int n=25;
  

  //printing out all of the column names to the outputfile
  outfile<<setprecision(13)<<setw(n)<<left<<"Starname"<<setw(n)<<left<<"RA_deg"<<setw(n)<<left<<"DEC_deg"<<setw(n)<<left<<"pm_RA_mas_yr"<<setw(n)<<left<<"pm_RA_mas_yr_err"<<setw(n)<<left<<"pm_DEC_mas_yr"<<setw(n)<<left<<"pm_DEC_mas_yr_err"<<setw(n)<<left<<"paralax_mas"<<setw(n)<<left<<"paralax_mas_err"<<setw(n)<<left<<"RV_km_s"<<setw(n)<<left<<"RV_km_s_err"<<setw(n)<<left<<"X"<<setw(n)<<left<<"Y"<<setw(n)<<left<<"Z"<<setw(n)<<left<<"U"<<setw(n)<<left<<"Uer"<<setw(n)<<left<<"V"<<setw(n)<<left<<"Ver"<<setw(n)<<left<<"W"<<setw(n)<<left<<"Wer"<<setw(n)<<left<<"Rapo"<<setw(n)<<left<<"Rapo_err_plus"<<setw(n)<<left<<"Rapo_err_minus"<<setw(n)<<left<<"Rperi"<<setw(n)<<left<<"Rperi_err_plus"<<setw(n)<<left<<"Rperi_err_minus"<<setw(n)<<left<<"zheight"<<setw(n)<<left<<"zheight_plus"<<setw(n)<<left<<"zheight_minus"<<setw(n)<<left<<"LX"<<setw(n)<<left<<"LX_plus"<<setw(n)<<left<<"LX_minus"<<setw(n)<<left<<"LY"<<setw(n)<<left<<"LY_plus"<<setw(n)<<left<<"LY_minus"<<setw(n)<<left<<"LZ"<<setw(n)<<left<<"LZ_sigma"<<setw(n)<<left<<"L_perp"<<setw(n)<<left<<"Lperp_sigma"<<setw(n)<<left<<"ecc"<<setw(n)<<left<<"ecc_plus"<<setw(n)<<left<<"ecc_minus"<<setw(n)<<left<<"Energy"<<setw(n)<<left<<"Energy_plus"<<setw(n)<<left<<"Energy_minus"<<setw(n)<<left<<"period"<<setw(n)<<left<<"period_plus"<<setw(n)<<left<<"period_minus"<<endl;

  //Reading the Inputfile and Sending observables (Heliocentric postion and velocites) to the integrator (convertfly.cc)
  for(int i=0;i<10000000;i++){
    //Just being careful and setting everything to Zero
    X=0;Y=0;Z=0;U=0;Uer=0;V=0;Ver=0;W=0;Wer=0;Rapo=0;Rapoplus=0;Rapominus=0;Rperi=0;Rperiplus=0;Rperiminus=0;zheight=0;zheightplus=0;zheightminus=0;LZ=0;sigLZ=0;LY=0;LYplus=0;LYminus=0;LX=0;LXplus=0;LXminus=0;Lperp=0;sigLperp=0;ecc=0;eccplus=0;eccminus=0;Energy=0;Energyplus=0;Energyminus=0;period=0;periodplus=0;periodminus=0;RA=0;DEC=0;epoch=0;ro=0;ro_err=0;mualpha=0,mualpha_err=0;mudelta=0;mudelta_err=0;pi=0;pi_err=0;alpha=0;delta=0;

    //Scan in from a file===================================
    /* UNITS
       RA.........Degrees
       DEC........Degrees
       PMRA.......mas/yr
       PMDEC......mas/yr
       Plx........mas  "note mas is prefered, but can handle parsec"
       RV.........Km/s
     */
    //Input file should be of this format
    // starname RA_deg DEC_deg pmRA_ pmRA_err pmDEC pmDEC_err Plx Plx_er RV RV_err
    int j =  fscanf(tmp,"%s %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",&starname,&RA,&DEC,&mualpha,&mualpha_err,&mudelta,&mudelta_err,&pi,&pi_err,&ro,&ro_err);
    if (j != 11){
      //      cout<<"End of File"<<endl;
      break;
    }
    //If not all info is there i.e. pi = nan (there is no distance info)
    if(mualpha != mualpha || mudelta != mudelta || pi != pi || ro != ro){
      cout <<"NOT Running star "<<starname<<" ....................."<<endl;
      outfile<<setprecision(13)<<setw(n)<<left<<starname<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<setw(n)<<left<<"nan"<<endl;
    }else{
      //All this is done to follow matrix operations in johnson and soderblom 1987AJ.....93..864J
      //The Conversion of Coordinate systems is done in convertfly.cc (Heliocentric -----> Galactocentric)
      //getting RA & Dec into radians
      alpha  = RA*(PI/180.);
      delta  = DEC*(PI/180.);
      mualpha /= 1000.0; mualpha_err /= 1000.; // converting to arcs/yr
      mudelta /= 1000.0; mudelta_err /= 1000.;// converting to arcs/yr
      

      double pi_original = pi,pi_err_original = pi_err;

    if(distancechoice == 0){
        pi /= 1000.;pi_err /= 1000.; //converting to arcsecs
    }else{
    //Input error is standard error in parsec
    // this is done as a work around for the 1/r relationship between parsec to parallax 
    // We try to get symmetric errors when converting from parsec to arcsec
     double pi_err_plus =  1./(pi + pi_err);
     double pi_err_minus = 1./(pi - pi_err);
     pi_err = (pi_err_minus + pi_err_plus)/2.; // we take the average
      //Input is distance in pc
     pi = 1./pi; // we invert to get arcsecs
}


      cout <<"Running star "<<starname<<" ....................."<<endl;
      //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      //Calling the Integrator
      //This will convert coordinates and integrate the star for a specipied integer of a Gigayear (the integer run time is passed to inputdegrees.cc as an argument
      convertfly(X,Y,Z,U,Uer,V,Ver,W,Wer,Rapo,Rapoplus,Rapominus,Rperi,Rperiplus,Rperiminus,zheight,zheightplus,zheightminus,LX,LXplus,LXminus,LY,LYplus,LYminus,LZ,sigLZ,Lperp,sigLperp,ecc,eccplus,eccminus,Energy,Energyplus,Energyminus,period,periodplus,periodminus,alpha,delta,pi,pi_err,ro,ro_err,mualpha,mualpha_err,mudelta,mudelta_err,choice,run,N);
      //Converting back to raw inputed data format
      mualpha *=1000.;mudelta *=1000.;mualpha_err *=1000.;mudelta_err *= 1000.;
      //This is where we have to change for inese======
      pi = pi_original;pi_err = pi_err_original;
      //This is where we have to change for inese======
      //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      //taking care of errors. If no errors were inputed them we set them to zero
      if(Uer == U){ Uer =0;} if(Ver == V){ Ver =0;}if(Wer == W){Wer =0;} if(Rapoplus == Rapo){ Rapoplus =0;}if(Rapominus == Rapo){ Rapominus =0;}
      if(Rperiplus == Rperi){ Rperiplus =0;} if(Rperiminus == Rperi){ Rperiminus =0;}if(zheightplus == zheight){zheightplus=0;}if(zheightminus == zheight){zheightminus=0;}
      if(LXplus == LX){LXplus =0;}if(LXminus == LX){LXminus =0;}if(LYplus == LY){LYplus =0;}if(LYminus == LY){LYminus =0;}if(eccplus == ecc){eccplus=0;}if(eccminus == ecc){eccminus=0;}if(Energyplus == Energy){Energyplus =0;}
      if(Energyminus == Energy){Energyminus =0;}if(periodplus == period){periodplus =0;}if(periodminus == period){periodminus =0;}
      
      //Printing results out to a file
      outfile<<setprecision(13)<<setw(n)<<left<<starname<<setw(n)<<left<<RA<<setw(n)<<left<<DEC<<setw(n)<<left<<mualpha<<setw(n)<<left<<mualpha_err<<setw(n)<<left<<mudelta<<setw(n)<<left<<mudelta_err<<setw(n)<<left<<pi<<setw(n)<<left<<pi_err<<setw(n)<<left<<ro<<setw(n)<<left<<ro_err<<setw(n)<<left<<X<<setw(n)<<left<<Y<<setw(n)<<left<<Z<<setw(n)<<left<<U<<setw(n)<<left<<Uer<<setw(n)<<left<<V<<setw(n)<<left<<Ver<<setw(n)<<left<<W<<setw(n)<<left<<Wer<<setw(n)<<left<<Rapo<<setw(n)<<left<<Rapoplus<<setw(n)<<left<<Rapominus<<setw(n)<<left<<Rperi<<setw(n)<<left<<Rperiplus<<setw(n)<<left<<Rperiminus<<setw(n)<<left<<zheight<<setw(n)<<left<<zheightplus<<setw(n)<<left<<zheightminus<<setw(n)<<left<<LX<<setw(n)<<left<<LXplus<<setw(n)<<left<<LXminus<<setw(n)<<left<<LY<<setw(n)<<left<<LYplus<<setw(n)<<left<<LYminus<<setw(n)<<left<<LZ<<setw(n)<<left<<sigLZ<<setw(n)<<left<<Lperp<<setw(n)<<left<<sigLperp<<setw(n)<<left<<ecc<<setw(n)<<left<<eccplus<<setw(n)<<left<<eccminus<<setw(n)<<left<<Energy<<setw(n)<<left<<Energyplus<<setw(n)<<left<<Energyminus<<setw(n)<<left<<period<<setw(n)<<left<<periodplus<<setw(n)<<left<<periodminus<<endl;
    }
  }
  fclose(tmp);outfile.close();
}
//============================================
//============================================
double arcsec_to_radian(double arcsec){
  arcsec /= 3600.0;
  arcsec *= PI/180.0;
  return arcsec;
}
//============================================
//============================================
double radian_to_arcsec(double radian){
  radian *= 648000.0 / PI ;
  return radian;
}
//============================================
//============================================
