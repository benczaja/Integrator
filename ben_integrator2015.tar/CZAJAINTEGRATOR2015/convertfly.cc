#include "vec3d.h"
#include <iostream>
#include <algorithm>
#include <math.h>
#include <stdio.h>
#include <fstream>
#include <iomanip>
#include <bitset>


using namespace std;


#define G 6.673e-20   //km^3/(kg*s^2)
#define m_e 5.974e24  // kg  mass of earth
#define m_s 1.989e30  // kg  mass of sun

const double year = 3.1536e7; // a year in seconds
const double KPC = 3.086e16; //km
const double PI = acos(-1.0);
const double h = 1e5*year;
const int number_potential = 5 + 1;

class body {
public:
  double m;
  vec3d r,v,a;
};
vec3d stepvlo(vec3d v, vec3d a, const double TIMESTEP);
vec3d steprlo(vec3d r, vec3d v, const double TIMESTEP);
vec3d stepvhi(vec3d v, vec3d a, const double TIMESTEP);
vec3d steprhi(vec3d r, vec3d v, const double TIMESTEP);
vec3d acceleration(vec3d r, double z, double R,double x, double y,int choice);
double potential(vec3d r,double z,double R,int choice,double time,double *bulge,double *disc,double *halo);
double helio_to_galactic(double &X,double &Y,double &Z,double &U,double &Uer,double &V,double &Ver,double &W,double &Wer,double alpha,double delta, double mualpha, double mualpha_error, double mudelta, double mudelta_error,double pi,double pi_error,double ro,double ro_error);
void assign_errors(body error_array[],int length,double Xer,double Yer,double Zer,double Uer,double Ver,double Wer);
void momentum_error(double &sigLz,double &sigLperp,double X,double Xer,double Y,double Yer,double Z,double Zer,double U,double Uer,double V,double Ver, double W,double Wer);
//====================================================
//====================================================
void convertfly(double &X,double &Y,double &Z,double &U,double &Uer,double &V,double &Ver,double &W,double &Wer,double &Rapo,double &Rapoplus,double &Rapominus,double &Rperi,double &Rperiplus,double &Rperiminus,double &zheight,double &zheightplus,double &zheightminus,double &LX,double &LXplus,double &LXminus,double &LY,double &LYplus,double &LYminus,double &LZ,double &sigLZ,double &Lperp,double &sigLperp,double &ecc,double &eccplus,double &eccminus,double &Energy,double &Energyplus,double &Energyminus,double &period,double &periodplus,double &periodminus,double alpha,double delta,double pi,double pi_error,double ro,double ro_error,double mualpha,double mualpha_error,double mudelta,double mudelta_error,int choice,double run,const int N){

  //converting trun "the runtime of the integrator" to seconds
  const double trun = run*1e9*year; 
  ofstream position,energy,Lz;
  position.open ("tmpposition.dat");
  energy.open("tmpenergy_conserv_check.dat");
  Lz.open("tmpmomentum_conserv_check.dat");
  vec3d r[64],print,rlo[64],vlo[64],rhi[64],vhi[64],L[64]; //setting these at 64 just sets our arrays to maximum value for N (This is a stupid work around for arrays of variable length)
  body b[64]; //defining our bodies to follow vec3d.h vector class
  L[N] = vec3d(0,0,0);

  double bulge=0,disc=0,halo=0;
  double R[N],z[N],r_avg[N],v_avg[N],zmax[N],L_X[N],L_Y[N],L_Z[N],L_perp[N];
  double infl_one[N],infl_two[N],infl_three[N],Rmax_avg[N],Rmax_avg_count[N],Rmin_avg[N],Rmin_avg_count[N];
  double E0(0.0),E[N],phi[N],period_[N];
  double e[N];
  double errmaxplus=0,errmaxminus=0,errminplus=0,errminminus=0,errzplus=0,errzminus=0,erreccplus=0,erreccminus=0,Eerrplus=0,Eerrminus=0,LXerrplus=0,LXerrminus=0,LYerrplus=0,LYerrminus=0;
  //  double sigLz=0,sigLperp=0;
  double Xer=0,Yer=0,Zer=0,cor=0;
  int count=0,max_count[N];
  double time=0;  //initial time

  
  //converting from observed heliocentric coordinates to galactic coordinates
  helio_to_galactic(X,Y,Z,U,Uer,V,Ver,W,Wer,alpha,delta,mualpha,mualpha_error,mudelta,mudelta_error,pi,pi_error,ro,ro_error);

  //For Position.... The Center of the galaxy is at the origin of a Cartesian coordinate system, with the disc in the X-Y plane.
  //For Velocity.... I am taking the definition of UVW from johnson and soderblom U (positive to galactic center) V (positive towards galactic rotation) W (positive toward galactic north pole). It may be confusing but in my code, the galaxy is rotating with positive "V" velocity at some (+X,0,0). This is done to keep orbital parameters consistant with the literature.
  //==========================================================
  //Position baby
  double distance = (1./pi)/1000.*KPC; // going from arcsecs to  km
  b[0].r = distance*vec3d(X,Y,Z); // Now in a cartesian coordinate system centered at the Sun units are in km
  b[0].r.x += 8.0*KPC; //Now we are centered at the Galactic Center
  //==========================================================
  //Velocity baby
  // Corrected for solar motion relative to LSR Schonrich,Binney, & Dehnen (2010)
  b[0].v = vec3d(-1.*(U-11.1),V+12.24,W+7.25);
  b[0].v.y += 220.0; //Boosting us to the LSR

  //Keeping all the Initial info around
  X= b[0].r.x/KPC; Y= b[0].r.y/KPC; Z= b[0].r.z/KPC;
  U = b[0].v.x; V = b[0].v.y; W = b[0].v.z;
  Uer = sqrt(Uer); Ver = sqrt(Ver); Wer = sqrt(Wer);
  //  cout<<X<<"  "<<Y<<"  "<<Z<<"  "<<U<<"  "<<V<<"  "<<W<<endl;
  // Calulating Angular momentum errors folowing Chiba and Beers 2000  (Just standard error propogation)
  momentum_error(sigLZ,sigLperp,X*KPC,Xer,Y*KPC,Yer,Z*KPC,Zer,U,Uer,V,Ver,W,Wer);

  LZ = (b[0].r % b[0].v).z/KPC;
  Lperp = sqrt((b[0].r % b[0].v).x * (b[0].r % b[0].v).x + (b[0].r % b[0].v).y * (b[0].r % b[0].v).y)/KPC;
  //assigning errors to bodies via bit masking
  if(N>1){
    assign_errors(b,N,Xer,Yer,Zer,Uer,Ver,Wer);
  }
  
  //Initializing most orbital variables i.e. "Angular Momentum" to zero
  //Also Calulating our bodies cylindrical coordinates. This is done in easy for out potentials.
  for(int i=0;i<N;i++){
    max_count[i]=0;Rmin_avg_count[i]=0;Rmax_avg_count[i]=0;
    Rmax_avg[i]=0;Rmin_avg[i]=0;L_X[i]=0;L_Y[i]=0;L_Z[i]=0;L_perp[i]=0;period_[i]=0;
    infl_one[i]=0;infl_two[i]=0;infl_three[i]=0;
    r_avg[i]=0;v_avg[i]=0;zmax[i]=0;
    r[i] = b[i].r;
    z[i] = b[i].r.z;
    R[i] = sqrt(b[i].r.x*b[i].r.x + b[i].r.y * b[i].r.y);
    
    // calc accel's at current time.
    b[i].a = acceleration(r[i],z[i],R[i],b[i].r.x,b[i].r.y,choice);   
    phi[i] = potential(b[i].r,b[i].r.z,R[i],choice,time,&bulge,&disc,&halo);
    E0 = 0.5*b[i].v*b[i].v + phi[i];
  }
  time = 0;
  //===================================================   
  //START OF THE STEPPING PROCESSS
  //===================================================   
  do{
    for(int i=0;i<N;i++){
      //       E[i] = 0.0;
      //Starting a Richard extrapolation step
      //-------------------------------------
      vlo[i] = stepvlo(b[i].v,b[i].a,h);
      rlo[i] = steprlo(b[i].r,vlo[i],h);
      
      vhi[i] = stepvhi(b[i].v,b[i].a,h);
      rhi[i] = steprhi(b[i].r,vhi[i],h); 
      
      //finishing the low precision timestep
      b[i].a = acceleration(rlo[i],rlo[i].z,sqrt(rlo[i].x*rlo[i].x + rlo[i].y*rlo[i].y),rlo[i].x,rlo[i].y,choice);   
      vlo[i] = stepvlo(vlo[i],b[i].a,h);
      
      //finishing the 1st high precision step and starting the 2nd High step
      b[i].a = acceleration(rhi[i],rhi[i].z,sqrt(rhi[i].x*rhi[i].x + rhi[i].y * rhi[i].y),rhi[i].x,rhi[i].y,choice);   
      vhi[i] = stepvhi(vhi[i],b[i].a,h);
      vhi[i] = stepvhi(vhi[i],b[i].a,h);
      rhi[i] = steprhi(rhi[i],vhi[i],h);
      
      //finishing the 2nd high precision step
      b[i].a = acceleration(rhi[i],rhi[i].z,sqrt(rhi[i].x*rhi[i].x + rhi[i].y * rhi[i].y),rhi[i].x,rhi[i].y,choice);   
      vhi[i] = stepvhi(vhi[i],b[i].a,h);
      
      //putting it all together
      b[i].v = (4.* vhi[i] - vlo[i])/3.;
      b[i].r = (4.* rhi[i] - rlo[i])/3.;
      //Ending a Richard extrapolation step  
      //-------------------------------------     
      
      //Rapo and Rperi and z_max
      //===========================================
      max_count[i] ++;    
      if(max_count[i]==1){
	infl_one[i] = b[i].r.norm();
      }
      if(max_count[i]==2){
	infl_two[i] = infl_one[i];
	infl_one[i] = b[i].r.norm();
      }
      if(max_count[i]>=3){
	infl_three[i] = infl_two[i];
	infl_two[i] = infl_one[i];
	infl_one[i] = b[i].r.norm();
	if(infl_one[i]<infl_two[i] && infl_two[i]>infl_three[i]){
	  Rmax_avg[i] += infl_two[i];
	  Rmax_avg_count[i] ++;
	}
	if(infl_one[i]>infl_two[i] && infl_two[i]<infl_three[i]){
	  Rmin_avg[i] += infl_two[i];
	  Rmin_avg_count[i] ++;
	}
      }
      if(fabs(b[i].r.z) > zmax[i]){
	zmax[i] = fabs(b[i].r.z);
      }
      R[i] = sqrt(b[i].r.x*b[i].r.x + b[i].r.y*b[i].r.y);     
      r_avg[i] += b[i].r.norm();
      v_avg[i] += b[i].v.norm();

      //here is where I want to calculate the angular momentumm and energy
      phi[i] = potential(b[i].r,b[i].r.z,R[i],choice,time,&bulge,&disc,&halo);       
      E[i] += 0.5*b[i].v.norm2() + phi[i];
      L_X[i] += (b[i].r % b[i].v).x;
      L_Y[i] += (b[i].r % b[i].v).y;
      L_Z[i] += (b[i].r % b[i].v).z;
      L_perp[i] += sqrt((b[i].r % b[i].v).x * (b[i].r % b[i].v).x + (b[i].r % b[i].v).y * (b[i].r % b[i].v).y );

      if(i==0){
	//Printing out to a file of position and momentum
	//could be useful to track conservation of things
	if ((count % 100) == 1){
	  //  printf(" t: %g yr E: %g dE/E0: %g [%d]\n",time/3e7,E,(E-E0)/E0,count);
	  //position
	  print = b[i].r;
	  print /= KPC;
	  position << print.x <<" "<<print.y<<" "<<print.z<<" "<<b[i].r.norm()/KPC<<" "<<time/year/1e9<<endl;;    
	  //Energy
	  //total : kinetic : potential : bulge : disc : halo : time
	  energy<<(0.5*b[i].v.norm2() + phi[i])<<" "<<0.5*b[i].v.norm2()<<" "<<phi[i]<<" "<<bulge<<" "<<disc<<" "<<halo<<" "<<time/10000000000.<<endl;
	  //Momentum
	  //total : Z comp : time
	  Lz<<(b[i].r % b[i].v).norm()/KPC/10.<<" "<<(b[i].r % b[i].v).z/KPC/10.<<" "<<time/1e8<<endl;
	}
      }
      //factors of energy for each potential to match the escape vel (500km/s) at 8.5 
      if(choice ==1){cor = 51424.;}
      if(choice ==3){cor = -48265.6;}
      if(choice ==4){cor = 12261.;}
    }
    //updating time
    time += h;
    count ++; // the counting variable it kept around to count how many timesteps have been taken
    // calc accel's at current time.
    for(int i=0;i<N;i++){
      b[i].a = acceleration(b[i].r,b[i].r.z,sqrt(b[i].r.x*b[i].r.x + b[i].r.y * b[i].r.y),b[i].r.x,b[i].r.y,choice);   
    }   
  }while(time<trun);
  
  //======================================================================
  //This is the end of the run
  //======================================================================

  //Calculation of eccen,Rapo,Rperi,Energy,z momentum AND ERRORS!!!
  for(int i=0;i<N;i++){
    Rmax_avg[i] /= Rmax_avg_count[i];
    Rmin_avg[i] /= Rmin_avg_count[i];
    E[i] /= count;
    L_X[i] /= count;L_Y[i] /= count;L_Z[i] /= count;L_perp[i] /= count; 
    e[i] = (Rmax_avg[i] - Rmin_avg[i])/(Rmin_avg[i] + Rmax_avg[i]);
    r_avg[i] /= count;
    v_avg[i] /= count;
    period_[i] = 2.0 *PI * r_avg[i]/v_avg[i];   
    period_[i] = period_[i]/3600.0/24.0/365.0/1e9; // this will get it into Gyr 
    if(i!=0){
      if(Rmax_avg[i]>Rmax_avg[0]){errmaxplus = Rmax_avg[i];}
      if(Rmax_avg[i]<Rmax_avg[0]){errmaxminus = Rmax_avg[i];}
      if(Rmin_avg[i]>Rmin_avg[0]){errminplus = Rmin_avg[i];}
      if(Rmin_avg[i]<Rmin_avg[0]){errminminus = Rmin_avg[i];}
      if(zmax[i]>zmax[0]){errzplus = zmax[i];}
      if(zmax[i]<zmax[0]){errzminus = zmax[i];}
      if(e[i]>e[0]){erreccplus = e[i];}
      if(e[i]<e[0]){erreccminus = e[i];} 
      if(E[i]>E[0]){Eerrplus = E[i];}
      if(E[i]<E[0]){Eerrminus = E[i];}
      if(L_X[i]>L_X[0]){LXerrplus = L_X[i];}
      if(L_X[i]<L_X[0]){LXerrminus = L_X[i];}
      if(L_Y[i]>L_Y[0]){LYerrplus = L_Y[i];}
      if(L_Y[i]<L_Y[0]){LYerrminus = L_Y[i];}
      if(period_[i]>period_[0]){periodplus = period_[i];}
      if(period_[i]<period_[0]){periodminus = period_[i];}
    }
  }

  period = period_[0];periodplus = fabs(period - periodplus);periodminus = fabs(period - periodminus);
  ecc = e[0];eccplus = fabs(erreccplus - e[0]);eccminus = fabs(erreccminus - e[0]);
  Rapo = Rmax_avg[0]/KPC; Rapoplus = fabs((Rmax_avg[0] - errmaxplus))/KPC; Rapominus = fabs((Rmax_avg[0] - errmaxminus)/KPC);
  Rperi = Rmin_avg[0]/KPC; Rperiplus = fabs((Rmin_avg[0] - errminplus)/KPC);Rperiminus = fabs((Rmin_avg[0] - errminminus)/KPC);
  zheight = zmax[0]/KPC;zheightplus = fabs((zmax[0] - errzplus)/KPC);zheightminus = fabs((zmax[0] - errzminus)/KPC);
  Energy = (E[0] + cor)/100.0;Energyplus = fabs(E[0]- Eerrplus)/100.;Energyminus = fabs(E[0]- Eerrminus)/100.; //need to fix Energy errors
  LX = L_X[0]/KPC; LXplus = fabs(L_X[0] - LXerrplus)/KPC/10.;LXminus = fabs(L_X[0] - LXerrminus)/KPC/10.; // keeping these around just for kicks
  LY = L_Y[0]/KPC; LYplus = fabs(L_Y[0] - LYerrplus)/KPC/10.;LYminus = fabs(L_Y[0] - LYerrminus)/KPC/10.; // keeping these around just for kicks
  sigLZ /= KPC;
  sigLperp /= KPC;
  //LZplus = fabs(L_Z[0] - LZerrplus)/KPC/10.;LZminus = fabs(L_Z[0] - LZerrminus)/KPC/10.; old angular momentum errors
  //Lperpplus = fabs(L_perp[0] - Lperperrplus)/KPC/10.;Lperpminus = fabs(L_perp[0] - Lperperrminus)/KPC/10.; old angular momentum errors
  for(int i=0;i<N;i++){
    L[i] = vec3d(0,0,0);
    Rmax_avg[i] = 0;
    Rmin_avg[i] = 0;
    Rmax_avg_count[i] = 0;
    Rmin_avg_count[i] = 0;
    zmax[i] = 0;
    r_avg[i]=0;
    v_avg[i]=0;   
  }
  count = 0;
  
  position.close();
  energy.close();
  Lz.close();
}
//============================================
//============================================
vec3d acceleration(vec3d r, double z, double R, double x, double y,int choice){
  vec3d accel,ab,ad,ah,rperp;
  double adperp=0,adz=0,abperp=0,abz=0;
  rperp = vec3d(x,y,0.0);
  
  //Kenyon potential====================== 
  if(choice == 1){
    const double Mb = m_s*3.76e9;
    const double Mh = m_s*1e12;
    const double Md = m_s*4e10;
    const double rb = 0.1 * KPC;
    const double rh = 20.0 *KPC;
    const double rd = 2. * KPC;
    const double bd = 0.3 * KPC;
    //acceleration from buldge
    ab = -G*Mb/( r*r + 2*r.norm()*rb + pow(rb,2))*r.unit();
    //acceleration from disc
    adperp =  -G*Md/sqrt(pow(R*R+pow(rd+sqrt(z*z+bd*bd),2.0),3.0))*R;
    adz = -G * Md * z * ( rd + sqrt ( z*z + bd *bd )) / ( pow( R*R + pow( rd + sqrt( z*z + bd*bd),2),1.5) * sqrt ( z*z + bd *bd )); 
    ad = adz*vec3d(0,0,1) + adperp*rperp.unit();
    //acceleration from halo
    ah = -(G*Mh * log (1 + r.norm()/rh) / (r*r) - G*Mh/(r.norm() * (rh + r.norm())))*r.unit();
    //updating the accels
    accel =  ab + ah + ad;
    return accel;
  }
  //Paczynski potential====================
  if(choice == 2){
    const double Mb = m_s*1.12e10;
    const double Mh = m_s*5.0e10;
    const double Md = m_s*8.07e10;
    const double rb = 0.0 * KPC;
    const double bb = 0.277 * KPC;
    const double rd = 3.7 * KPC;
    const double bd = 0.2 * KPC;
    const double bh = 6.0 * KPC;
    //acceleration from buldge
    abperp =  -G*Mb/sqrt(pow(R*R+pow(rb+sqrt(z*z+bb*bb),2.0),3.0))*R;
    abz = -G * Mb * z * ( rb + sqrt ( z*z + bb *bb )) / ( pow( R*R + pow( rb + sqrt( z*z + bb*bb),2),1.5) * sqrt ( z*z + bb *bb )); 
    ab = abz*vec3d(0,0,1) + abperp*rperp.unit();
    //acceleration from disc
    adperp =  -G*Md/sqrt(pow(R*R+pow(rd+sqrt(z*z+bd*bd),2.0),3.0))*R;
    adz = -G * Md * z * ( rd + sqrt ( z*z + bd *bd )) / ( pow( R*R + pow( rd + sqrt( z*z + bd*bd),2),1.5) * sqrt ( z*z + bd *bd )); 
    ad = adz*vec3d(0,0,1) + adperp*rperp.unit();
    //acceleration from halo
    ah = -G*Mh/bh*(r/(bh*bh+r*r) + (bh/(r*r))*(bh*r/(bh*bh + r*r) - r.unit()*atan(r.norm()/bh)));
    //updating the accels
    accel =  ab + ah + ad;
    return accel;
  }
  //Kathryn Johnston potential==============
  if(choice == 3){
    const double Mb = m_s*3.4e10;
    const double Md = m_s*10e10;
    const double c = 0.7 * KPC;
    const double bh = 12.0 * KPC;
    const double rd = 6.5 * KPC;
    const double bd = 0.26 * KPC;
    const double vo = 128.0; //km/s
    //acceleration from buldge
    ab = -G*Mb/(r*r + 2*r.norm()*c + c*c)*r.unit();
    //acceleration from disc
    adperp =  -G*Md/sqrt(pow(R*R+pow(rd+sqrt(z*z+bd*bd),2.0),3.0))*R;
    adz = -G * Md * z * ( rd + sqrt ( z*z + bd *bd )) / ( pow( R*R + pow( rd + sqrt( z*z + bd*bd),2),1.5) * sqrt ( z*z + bd *bd )); 
    ad = adz*vec3d(0,0,1) + adperp*rperp.unit();
    //acceleration from halo
    ah = -2*r*vo*vo/(r*r + bh*bh);
    //updating the accels
    accel =  ab + ah + ad;
    return accel;  
  }
  //Dauphole potential====================
  if(choice == 4){
    const double Mb = m_s*1.396e10;
    const double Mh = m_s*6.978e11;
    const double Md = m_s*7.908e10;
    const double bb = 0.35 * KPC;
    const double bh = 24.0 *KPC;
    const double rd = 3.55 * KPC;
    const double bd = 0.25 * KPC;
    //acceleration from buldge
    ab = - G * Mb * r / pow(bb*bb + r.norm2(),1.5);
    //acceleration from disc
    adperp =  -G*Md/sqrt(pow(R*R+pow(rd+sqrt(z*z+bd*bd),2.0),3.0))*R;
    adz = -G * Md * z * ( rd + sqrt ( z*z + bd *bd )) / ( pow( R*R + pow( rd + sqrt( z*z + bd*bd),2),1.5) * sqrt ( z*z + bd *bd )); 
    ad = adz*vec3d(0,0,1) + adperp*rperp.unit();
    //acceleration from halo
    ah = -G*Mh*r/pow(r*r + bh*bh,1.5);
    //updating the accels
    accel =  ab + ah + ad;
    return accel;
  }
  //Allen potential=========================
  if(choice == 5){
    const double Mb = m_s*606.*2.32e7;
    const double bb = 0.3873*KPC;
    const double Md = m_s*3690.*2.32e7;
    const double rd = 5.3178*KPC;
    const double bd = 0.25*KPC;
    const double Mh = m_s*4615.*2.32e7;
    const double rh = 12.*KPC;
    //bulge
    ab = - G * Mb * r / pow(bb*bb + r.norm2(),1.5);
    //disc
    adperp =  -G*Md/sqrt(pow(R*R+pow(rd+sqrt(z*z+bd*bd),2.0),3.0))*R;
    adz = -G * Md * z * ( rd + sqrt ( z*z + bd *bd )) / ( pow( R*R + pow( rd + sqrt( z*z + bd*bd),2),1.5) * sqrt ( z*z + bd *bd )); 
    ad = adz*vec3d(0,0,1) + adperp*rperp.unit();
    //halo
    ah += - G*Mh*(-rh*pow(r.norm()/rh,3.04) + r.norm()*pow(r.norm()/rh,2.04) - rh*pow(r.norm()/rh,2.02) + 2.02*r.norm()*pow(r.norm()/rh,1.02))*r.unit()/(rh*r.norm2()*(pow(r.norm()/rh,1.02) +1.)*(pow(r.norm()/rh,1.02) +1.));
    // the 100 KPC cutoff    
    if(r.norm()<100.*KPC){  
      ah += (-G*Mh/(1.02*rh))*(1.0404*pow(r.norm()/rh,0.02)/(rh*(pow(r.norm()/rh,1.02) +1.)*(pow(r.norm()/rh,1.02) +1.)))*r.unit();
      ah += (-G*Mh/(1.02*rh))*(1.02*pow(r.norm()/rh,0.02)/(rh*(pow(r.norm()/rh,1.02) + 1.)))*r.unit();
    }
    //total
    accel = ab + ad + ah;
    ah = vec3d(0,0,0);
    return accel;
  }  
}
//============================================
//============================================
double potential(vec3d r,double z,double R,int choice,double time,double *bulge,double *disc, double *halo){
  double phi_T=0;
  //Kenyon potential====================== 
  if(choice ==1){
    const double Mb = m_s*3.76e9;
    const double Mh = m_s*1e12;
    const double Md = m_s*4e10;
    const double rb = 0.1 * KPC;
    const double rh = 20.0 *KPC;
    const double rd = 2. * KPC;
    const double bd = 0.3 * KPC;

    /*   
     *bulge = -G*Mb/(r.norm() + rb);
    *disc = -G*Md / sqrt ( R*R + ( rd + sqrt(z*z + bd*bd)) * ( rd + sqrt(z*z + bd*bd)));
    *halo = -G*Mh * log ( 1 + r.norm()/rh)/r.norm();
    */
    phi_T += -G*Mb/(r.norm() + rb);
    phi_T += -G*Md / sqrt ( R*R + ( rd + sqrt(z*z + bd*bd)) * ( rd + sqrt(z*z + bd*bd)));
    phi_T += -G*Mh * log ( 1. + r.norm()/rh)/r.norm();
    //phi_T = *bulge + *disc + *halo;
    return phi_T;
  }
  //Paczynski potential====================
  if(choice == 2){
    const double Mb = m_s*1.12e10;
    const double Mh = m_s*5.0e10;
    const double Md = m_s*8.07e10;
    const double rb = 0.0 * KPC;
    const double bb = 0.277 * KPC;
    const double rd = 3.7 * KPC;
    const double bd = 0.2 * KPC;
    const double bh = 6.0 * KPC;

    *bulge = -G*Mb / sqrt ( R*R + (rb + sqrt (z*z + bb*bb))*(rb + sqrt (z*z + bb*bb)));
    *disc = -G*Md / sqrt ( R*R + (rd + sqrt (z*z + bd*bd))*(rd + sqrt (z*z + bd*bd)));
    *halo = -(G*Mh/bh)*(0.5*log(1.+ (r.norm2())/(bh*bh)) + (bh/r.norm()) * atan(r.norm()/bh));

    phi_T = (*bulge + *disc + *halo); //4.3e4;

    return phi_T;
  } 
  //Kathryn Johnston potential==============
  if(choice == 3){
    const double Mb = m_s*3.4e10;
    const double Md = m_s*10e10;
    const double c = 0.7 * KPC;
    const double bh = 12.0 * KPC;
    const double rd = 6.5 * KPC;
    const double bd = 0.26 * KPC;
    const double vo = 128.0; //km/s

    phi_T += -G*Mb/(r.norm() + c);
    phi_T += -G*Md / sqrt ( R*R + (rd + sqrt (z*z + bd*bd))*(rd + sqrt (z*z + bd*bd)));
    phi_T += vo*vo*log(1. + (r*r)/(bh*bh));
    phi_T += -5.2e4;

    return phi_T;
  }
  //Dauphole potential====================
  if(choice == 4){
    const double Mb = m_s*1.396e10;
    const double Mh = m_s*6.978e11;
    const double Md = m_s*7.908e10;
    const double bb = 0.35 * KPC;
    const double bh = 24.0 *KPC;
    const double rd = 3.55 * KPC;
    const double bd = 0.25 * KPC;

    phi_T += -G*Mb/sqrt(r*r + bb*bb);
    phi_T += -G*Md / sqrt ( R*R + (rd + sqrt (z*z + bd*bd))*(rd + sqrt (z*z + bd*bd)));
    phi_T += -G*Mh/sqrt(r*r + bh*bh);
    return phi_T;
  }
  //Allen potential=========================
  if(choice == 5){
    const double Mb = m_s*606.*2.32e7;
    const double bb = 0.3873*KPC;
    const double Md = m_s*3690.*2.32e7;
    const double rd = 5.3178*KPC;
    const double bd = 0.25*KPC;
    const double Mh = m_s*4615.*2.32e7;
    const double rh = 12.*KPC;
    phi_T += -G*Mb/sqrt(r.norm2() + bb*bb);
    phi_T += -G*Md/sqrt ( R*R + (rd + sqrt (z*z + bd*bd))*(rd + sqrt (z*z + bd*bd)));
    phi_T += -G*Mh*pow(r.norm()/rh,2.02)/(1. + pow(r.norm()/rh,1.02))/r.norm();

    // 100kpc cutoff
    if(r.norm()<100.*KPC){
      phi_T += (-G*Mh/(1.02*rh))*(-1.02/(1. + pow(r.norm()/rh,1.02)) + log(1. + pow(r.norm()/rh,1.02))); 
    }else{
      phi_T += -G*Mh/(1.02*rh);
    }
    return phi_T;
  }
}

//============================================
//============================================
vec3d stepvlo(vec3d v, vec3d a, const double TIMESTEP){
  v += 0.5 * TIMESTEP *a;
  return v;
}
//============================================
//============================================
vec3d steprlo(vec3d r, vec3d v, const double TIMESTEP){
  r += TIMESTEP*v;
  return r;
}
//============================================
//============================================
vec3d stepvhi(vec3d v, vec3d a, const double TIMESTEP){
   v += 0.25 * TIMESTEP *a;
  return v;
}
//============================================
//============================================
vec3d steprhi(vec3d r, vec3d v, const double TIMESTEP){
  r += 0.5*TIMESTEP*v;
  return r;
}
//============================================
//============================================
double helio_to_galactic(double &X,double &Y,double &Z,double &U,double &Uer,double &V,double &Ver,double &W,double &Wer,double alpha,double delta, double mualpha, double mualpha_error, double mudelta, double mudelta_error,double pi,double pi_error,double ro,double ro_error){
  
  double Ti[3][3],T[3][3],Ttheta[3][3],Talpha[3][3],Tdelta[3][3];
  double A[3][3],B[3][3],last[3],UVW[3],UVW_error[3],poss[3],eqposs[3],C[3][3];
  double  error1[3],error2[3];
  double k = 4.74057;
  double theta0= 123.0,deltaNGP = 27.4,alphaNGP = 192.25; // degrees
  
  //converting to radians
  theta0 = (theta0/180.0)*PI;
  deltaNGP = (deltaNGP/180.0)*PI;
  alphaNGP = (alphaNGP/180.0)*PI;
  
  
  //==========================================================
  //==========================================================
  for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
      Ttheta[i][j]=0;    
      Ti[i][j]=0;    
      T[i][j]=0;    
      Tdelta[i][j]=0;    
      Talpha[i][j]=0;    
      A[i][j]=0;
      B[i][j]=0;
      C[i][j]=0;
    }
    last[i]=0;
    UVW[i]=0;   
    UVW_error[i]=0;   
    poss[i]=0;   
    eqposs[i]=0; 
    error1[i]=0;  
    error2[i]=0;  
  }
  Ttheta[0][0] = cos(theta0);
  Ttheta[0][1] = sin(theta0);
  Ttheta[0][2] = 0.0;
  Ttheta[1][0] = sin(theta0);
  Ttheta[1][1] = -1.0*cos(theta0);
  Ttheta[1][2] = 0.0;
  Ttheta[2][0] = 0.0;
  Ttheta[2][1] = 0.0;
  Ttheta[2][2] = 1.0;
      
  Tdelta[0][0] = -1.0*sin(deltaNGP);
  Tdelta[0][1] = 0.0;
  Tdelta[0][2] = cos(deltaNGP);
  Tdelta[1][0] = 0.0;
  Tdelta[1][1] = -1.0;
  Tdelta[1][2] = 0.0;
  Tdelta[2][0] = cos(deltaNGP);
  Tdelta[2][1] = 0.0;
  Tdelta[2][2] = sin(deltaNGP);
      
  Talpha[0][0] = cos(alphaNGP);
  Talpha[0][1] = sin(alphaNGP);
  Talpha[0][2] = 0.0;
  Talpha[1][0] = sin(alphaNGP);
  Talpha[1][1] = -1.0*cos(alphaNGP);
  Talpha[1][2] = 0.0;
  Talpha[2][0] = 0.0;
  Talpha[2][1] = 0.0;
  Talpha[2][2] = 1.0;

  A[0][0] = cos(alpha) * cos(delta);
  A[0][1] = -sin(alpha);
  A[0][2] = -cos(alpha) * sin(delta);
  A[1][0] = sin(alpha) * cos(delta);
  A[1][1] = cos(alpha);
  A[1][2] = -sin(alpha) * sin(delta);
  A[2][0] =  sin (delta);
  A[2][1] = 0.0;
  A[2][2] = cos (delta);

  eqposs[0]= cos(delta) * cos(alpha);
  eqposs[1]= cos(delta) * sin(alpha);
  eqposs[2]= sin(delta);

  last[0]= ro; 
  last[1]= k * mualpha /pi; 
  last[2]= k * mudelta /pi; 

  error1[0] = ro_error * ro_error;
  error1[1] = ((k*k)/(pi*pi))*(mualpha_error * mualpha_error + (mualpha * pi_error/pi)*(mualpha * pi_error/pi));
  error1[2] = ((k*k)/(pi*pi))*(mudelta_error * mudelta_error  + (mudelta * pi_error/pi)*(mudelta * pi_error/pi));
 
  error2[0] = ((2.0 * mualpha * mudelta * k * k * pi_error * pi_error) / (pi*pi*pi*pi)) ;
  error2[1] = ((2.0 * mualpha * mudelta * k * k * pi_error * pi_error) / (pi*pi*pi*pi)) ;
  error2[2] = ((2.0 * mualpha * mudelta * k * k * pi_error * pi_error) / (pi*pi*pi*pi)) ;
  //==========================================================
  // Here is a bunch of matrix operations to get the data given by astronomers into Galactic Coordinates
  //==========================================================
  for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
      for(int k=0;k<3;k++){
 	Ti[i][j] += Tdelta[i][k] * Talpha[k][j] ;
      }
    }
  }
   for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
      for(int k=0;k<3;k++){
	T[i][j] += Ttheta[i][k] * Ti[k][j] ;
      }
    }
  }
  for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
      for(int k=0;k<3;k++){
	B[i][j] += T[i][k] * A[k][j] ;
      }
    }
 }
 for(int i=0;i<3;i++){
   for(int j=0;j<3;j++){
     UVW[i] += B[i][j]*last[j];   
   }
 }
 //=====================================
 //errors
 //=====================================
 for(int i=0;i<3;i++){
   for(int j=0;j<3;j++){
     C[i][j]= B[i][j] * B[i][j];
   }
 }
 for(int i=0;i<3;i++){
   for(int j=0;j<3;j++){
     UVW_error[i] += C[i][j] * error1[j];
   }
 }
 for(int i=0;i<3;i++){
   UVW_error[i] += error2[i]*B[1][i]*B[2][i];
 }
 //==========================================================
 //Position Matrix
 for(int i=0;i<3;i++){
   for(int j=0;j<3;j++){
     poss[i] += T[i][j] * eqposs[j];
   }
 }
 X=poss[0];Y=poss[1];Z=poss[2];U=UVW[0];V=UVW[1];W=UVW[2];Uer=UVW_error[0];Ver=UVW_error[1];Wer=UVW_error[2];
}
void assign_errors(body error_array[],int length,double Xer,double Yer,double Zer,double Uer,double Ver,double Wer){
  //assigning errors to bodies via bit masking
  bitset<6> one(1),two(2),four(4),eight(8),sixteen(16),thirtytwo(32),mask(0);
  double x,y,zz,u,v,w;
  for(int i=0;i<length;i++){
    x=Xer;y=Yer;zz=Zer;u=Uer;v=Ver;w=Wer;
    bitset<6> bin(i);
    //test x place
    mask = bin & one;
    if(mask == 1){x *= -1.;}else{x *= 1.;}
    //test y place
    mask = bin & two;if(mask == 2){y *= -1.;}else{y *= 1.;}  
    //test z √place
    mask = bin & four;if(mask == 4){zz *= -1.;}else{zz *= 1.;}  
    //test u place 
    mask = bin & eight;if(mask == 8){u *= -1.;}else{u *= 1.;} 
    //test v
    mask = bin & sixteen;if(mask == 16){v *= -1.;}else{v *= 1.;}  
    //test w
    mask = bin & thirtytwo;if(mask == 32){w *= -1.;}else{w *= 1.;}  

    error_array[i+1].r.x = error_array[0].r.x + x*KPC;
    error_array[i+1].r.y = error_array[0].r.y + y*KPC; 
    error_array[i+1].r.z = error_array[0].r.z + zz*KPC;
    error_array[i+1].v.x = error_array[0].v.x + u;
    error_array[i+1].v.y = error_array[0].v.y + v; 
    error_array[i+1].v.z = error_array[0].v.z + w;
    //   cout<<b[0].r/KPC<<endl<<b[i+1].r/KPC<<endl<<b[0].v<<endl<<b[i+1].v<<endl<<endl;
  }
}
void momentum_error(double &sigLz,double &sigLperp,double X,double Xer,double Y,double Yer,double Z,double Zer,double U,double Uer,double V,double Ver, double W,double Wer){
  double R = sqrt(X*X +Y*Y);
  double sigR = sqrt( (X*X*Xer*Xer)/(X*X + Y*Y) + (Y*Y*Yer*Yer)/(X*X+Y*Y));
  sigLz = sqrt((V*V)*(sigR*sigR) + R*R*Ver*Ver);
  
  double denominator = sqrt((W*X + U*Z)*(W*X + U*Z) + (W*Y + V*Z)*(W*Y + V*Z));
  double dLdx = W*(W*X-U*Z)/denominator;
  double dLdy = W*(W*Y-V*Z)/denominator;
  double dLdz = (U*U*Z - U*W*X + V*(V*Z-W*Y))/denominator;
  double dLdu = Z*(U*Z-W*X)/denominator;
  double dLdv = Z*(V*Z-W*Y)/denominator;
  double dLdw = (W*R*R - Z*(U*X+V*Y))/denominator;
  sigLperp = sqrt(dLdx*dLdx*Xer*Xer + dLdy*dLdy*Yer*Yer + dLdz*dLdz*Zer*Zer + dLdu*dLdu*Uer*Uer + dLdv*dLdv*Ver*Ver + dLdw*dLdw*Wer*Wer);

}
